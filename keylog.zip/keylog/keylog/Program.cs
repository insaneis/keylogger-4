﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Diagnostics;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;





namespace keylog
{
    class Program
    {
        static void Main(string[] args)
        {

            keys app = new keys();
            app.klavesi_vstup();
        


        }
    }
}
